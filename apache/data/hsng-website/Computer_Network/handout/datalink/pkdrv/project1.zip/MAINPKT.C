// mainpkt.c
#include "pkt.h"
#include "pcpkt.c"
#include <ctype.h>
#include <math.h>
/***********************************************************/
unsigned char ipid = 1;
longword n2hlong(longword dati)
{
   char *in = (char *)&dati;
   longword dato;
   char *out = (char *)&dato;

   out[0] = in[3];
   out[1] = in[2];
   out[2] = in[1];
   out[3] = in[0];
   return(dato);
}
/***********************************************************/
word n2hword(word in)
{
   word out;

   swab((char *)&in, (char *)&out, sizeof(word));
   return(out);
}
/***********************************************************/
longword h2nlong(longword dati)
{
   char *in = (char *)&dati;
   longword dato;
   char *out = (char *)&dato;

   out[0] = in[3];
   out[1] = in[2];
   out[2] = in[1];
   out[3] = in[0];
   return(dato);
}
/***********************************************************/
word h2nword(word in)
{
   word out;

   swab((char *)&in, (char *)&out, sizeof(word));
   return(out);
}
/***********************************************************/
longword char2long(char *charip)
{
  longword ip1, ip2, ip3, ip4,out;

  sscanf(charip, "%ld.%ld.%ld.%ld", &ip1, &ip2, &ip3, &ip4);
  out = ip1*(1L<<24)+ip2*(1L<<16)+ip3*(1L<<8)+ip4;
  return out;

}
/***********************************************************/
void long2char(longword longip, char *charip)
{
   int ip1, ip2, ip3, ip4;

   ip4 = longip%(1L<<8);
   ip3 = ((longip%(1L<<16))-ip4) / (1L<<8);
   ip2 = ((longip%(1L<<24))-ip3*(1L<<8)-ip4) / (1L<<16);
   ip1 = (longip-ip2*(1<<16)-ip3*(1L<<8)-ip4) / (1L<<24);
   sprintf(charip, "%d.%d.%d.%d", ip1, ip2, ip3, ip4);
}
/**********************************************/
void printaddr(void)
{
   char *ft = "IP address=%s  Hardware address=%02x:%02x:%02x:%02x:%02x:%02x\n";
   printf(ft, srccip,srchw[0],srchw[1],srchw[2],srchw[3],srchw[4],srchw[5]);
}
/**********************************************/
void printinfo(void)
{
  printf("Version = %d\n", drvinfo->Version);
  printf("Class = %d\n", drvinfo->Class);
  printf("Type= %d\n", drvinfo->Type);
  printf("Number = %d\n", drvinfo->Number);
  printf("Name = %s\n", drvinfo->Name);
  printf("Functionality = ");
  switch (drvinfo->Functionality)
	 { case 1 : printf("basic functions.\n");
		    break;
	   case 2 : printf("basic and extended.\n");
		    break;
	   case 3 : printf("basic and high-performance.\n");
		    break;
	   case 4 : printf("basic, high-performance, extended.\n");
		    break;
	   default: printf("Not installed.\n");}
}
/**********************************************/
void send_ip(char *str , int length)
{
   eth_Header *etho = (eth_Header *) Gbuf;
   length_Header *leno = (length_Header *) (Gbuf+sizeof(eth_Header));
   int data_length,old_offset=0;

   do {
     if ( length <= 1000 ) {
       data_length = length;
       length = 0;
     }
     else {
       data_length = 1000;
       length = length - 1000;
     }
     memset(Gbuf, 0, BUFSIZE);
     memcpy(etho->dst, dsthw, 6);
     memcpy(etho->src, srchw, 6);
     etho->type = ip_type;
     leno->length=n2hword((word) (data_length));
     memcpy(Gbuf+sizeof(eth_Header)+sizeof(length_Header),str+old_offset,data_length);
     send_pkt(Gbuf, sizeof(eth_Header)+sizeof(length_Header)+data_length);
     old_offset = old_offset + data_length;
   } while ( data_length == 1000 && length !=0 );
}
/**********************************************/
int ip_pro(char *buff,char  *recv_buf)
{
  length_Header *leno;
  int i=0;
  char *temp;
  leno = (length_Header *) buff;
  i = (int) h2nword(leno->length);
  temp = (char *) (buff+sizeof(length_Header));
  memcpy ( recv_buf,temp,i);
  return i;
}
/**********************************************/
int process(char *buff, char  *recv_buf)
{
   eth_Header *eth;
   int i=0;

   eth = (eth_Header *) buff;
   switch (eth->type)
	  { case 0x0008 :
//     got data packet
			  i = ip_pro(buff+14,recv_buf);
			  break;
	    default     : break;}
   return i;
}
/*********************************************
 */
int pkt_init(void)
{
   _pktasminit(pktbuf, MAXBUFS, BUFSIZE);
   if ((pkt_interrupt = get_vector()) == 0XFFFF)
      return(-1);
   if ((drvinfo = driver_info()) == NULL)
      return(-1);
   ip_handle  = access_type(drvinfo->Class, drvinfo->Type, drvinfo->Number,
			    (char far *)&ip_type, sizeof(ip_type), _pktentry);
   get_address(ip_handle, srchw, 6);
   printaddr();
   printinfo();
   set_rcv_mode(ip_handle, 2);
   return(1);
}
/**********************************************/
void pinit(char *src,char *dst)
{
   int xatoi(char *);
   int tmp,i;
   char *temp,macsep[]=":",dstmac[20];

   strcpy(dstmac,dst);
   temp=strtok(dstmac,macsep);
   for (i=0;i<6;i++) {
     tmp = xatoi(temp);
     dsthw[i]=tmp;
     temp=strtok(NULL,macsep);
   }
   printf("destination address = %02x:%02x:%02x:%02x:%02x:%02x \n", dsthw[0],
	  dsthw[1], dsthw[2], dsthw[3], dsthw[4], dsthw[5]);
   memset(srccip, 0, 16);
   memcpy(srccip, src, MIN(strlen(src),15));
   srclip = char2long(srccip);
   if (pkt_init() < 0)
      return;
}
/**********************************************/
int precv(char  *recv_buf)
{
  int index = 0,i;

  if (pktbuf[index].busy == 1) {
    i = process(pktbuf[index].buff, recv_buf);
    pktbuf[index].busy = 0;
    return (i);
  }
  else {
    return 0;
  }
}
int xatoi(char *ss)
{
  int len,index,i,value=0,upr,tmp;
  char *ptr;

  len=strlen(ss);
  index=0;
  for(i=len-1;i>=0;i--) {
    upr=0;
    if ( isalpha(ss[i])) {
      if (!isxdigit(ss[i])) {
	printf("It's not a hex digit\n");
	return -1;
      }
      ptr = strupr(&ss[i]);
      upr = (int) *ptr;
      value=value+ ( upr - 'A' + 10 )*(int) pow((double)16,(double)index);
    } else if ( isdigit((int)ss[i])) {
      tmp = (int) ss[i];
      value=value+ (tmp-'0')*(int) pow((double)16,(double)index);
    } else {
      printf("It's not a digit i=%d \n");
      return -1;
    }
    index++;
  }
  return value;
}
/**********************************************/
void main(int argc, char **argv)
{
   void sendfile(char *,int);
   void recvfile(char *,int);
   void send_ip(char *,int);

   int i,cflag=0,k;
   char *recv_buf;
   char command[80],*cmd,*filename;
   char sep[]=" ";

   if (argc < 3)
      { printf("Usage : %s MyIP RemoteMAC\n",argv[0]);
	return;}
   pinit(argv[1],argv[2]);
   printf("OK! Now you can transfer files\n");
   printf("Type help to get command list\n");
   while (1) {
     command[0]='\0';
     while (strlen(command) == 0) {
       printf("Command:>");
       gets(command);
     }
     cmd=strtok(command,sep);
     if (strnicmp("quit",cmd,4)==0) {
       break;
     } else if (strnicmp("help",cmd,4)==0) {
       printf("\nFile Transfer Demo Program. Written by TiuN Hong Leng\n");
       printf("To transfer file, the other side must have run \"get\"\n");
       printf("help         To get this menu\n");
       printf("get          Use \"get filename\" to receive file\n");
       printf("put          Use \"put filename\" to send file\n");
       printf("count        Toggle on|off to display total bytes send(received);\n");
       printf("quit         To quit this program\n");
     } else
     if (strnicmp("get",cmd,3)==0) {
       filename=strtok(NULL,sep);
       printf("Received file from %s and store to %s\n",argv[2],filename);
       recvfile(filename,cflag);
     } else if (strnicmp("put",cmd,3)==0) {
       filename=strtok(NULL,sep);
       printf("Send file %s to %s\n",filename,argv[2]);
       sendfile(filename,cflag);
     } else if( strnicmp("count",cmd,5) == 0) {
       cflag=1-cflag;
     } else {
       printf("No such command\n");
       continue;
     }
   }
   release_type(ip_handle);
}
void sendfile(char *filename, int cflag)
{
  FILE *fptr;
  char  *send_buf;
  char eof[]="FILEEOF";
  int i=0;
  long total=0;
  struct  time start,end;

  if ((fptr=fopen(filename,"rb"))==NULL) {
    printf("No such file or file open error!\n");
    return;
  }

  i=fread(send_buf,1,600,fptr);
  if ( i <= 0 )
    printf("error\n");
  total+=i;
  gettime(&start);
  if ( cflag == 1) {
    while (i !=0) {
      delay(2);
      send_ip(send_buf,i);
      i=fread(send_buf,1,600,fptr);
      total+=i;
      printf("\r%ld bytes",total);
      fflush(fptr);
    }
  } else {
    while (i !=0) {
      delay(10);
      send_ip(send_buf,i);
      i=fread(send_buf,1,600,fptr);
      total+=i;
      fflush(fptr);
    }
  }
  gettime(&end);
  printf("\nStart  time is: %2d:%02d:%02d.%02d\n",
    start.ti_hour, start.ti_min, start.ti_sec, start.ti_hund);
  printf("Finish time is: %2d:%02d:%02d.%02d\n",
    end.ti_hour, end.ti_min, end.ti_sec, end.ti_hund);
  printf("Total Size = %ld bytes\n",total);
  send_ip(eof,7);
  fclose(fptr);
  return;
}
void recvfile(char *filename,int cflag)
{
  FILE *fptr;
  char *recv_buf;
  int j,flag=0;
  long total=0;
  struct  time start,end;

  if ((recv_buf = (char *) malloc(1000)) == NULL) {
   printf("Not enough memory to allocate buffer\n");
   exit(1);  /* terminate program if out of memory */
  }

  if ((fptr=fopen(filename,"wb")) == NULL) {
    printf("File open error!\n");
    return;
  }
  if (cflag == 0) {
    while(1) {
      j = precv(recv_buf);
      if ( j != 0) {
	if (flag == 0) {
	  gettime(&start);
	  flag=1;
	}
	if (j==7) {
	  if ( strncmp(recv_buf,"FILEEOF",7) == 0 ) {
	    break;
	  }
	}
	total+=j;
	fwrite(recv_buf,1,j,fptr);
	fflush(fptr);
      }
    }
  } else {
    while(1) {
      j = precv(recv_buf);
      if ( j != 0) {
	if (flag == 0) {
	  gettime(&start);
	  flag=1;
	}
	if (j==7) {
	  if ( strncmp(recv_buf,"FILEEOF",7) == 0 ) {
	    break;
	  }
	}
	total+=j;
	fwrite(recv_buf,1,j,fptr);
	fflush(fptr);
	printf("\r%ld bytes",total);
      }
    }
  }
  gettime(&end);
  printf("\nStart  time is: %2d:%02d:%02d.%02d\n",
    start.ti_hour, start.ti_min, start.ti_sec, start.ti_hund);
  printf("Finish time is: %2d:%02d:%02d.%02d\n",
    end.ti_hour, end.ti_min, end.ti_sec, end.ti_hund);
  printf("Total size = %ld bytes\n",total);
  fclose(fptr);
  return;
}
