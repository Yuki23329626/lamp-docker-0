// pcpkt.c
int ERROR_check(union REGS reg)
{
  if (reg.x.cflag & CARRY)
     { switch (reg.h.dh)
         { case  1 : printf("\07 Invalid handle number.\n");
		     return(-1);
	   case  2 : printf("\07 No interfaces of specified class found.\n");
	             return(-1);
	   case  3 : printf("\07 No interfaces of specified type found.\n");
		     return(-1);
	   case  4 : printf("\07 No interfaces of specified number found.\n");
		     return(-1);
	   case  5 : printf("\07 Bad packet type specified.\n");
		     return(-1);
	   case  6 : printf("\07 The interface does not support multicast.\n");
		     return(-1);
	   case  7 : printf("\07 This packet driver cannot terminate.\n");
		     return(-1);
	   case  8 : printf("\07 An invalid receiver mode was specified.\n");
		     return(-1);
	   case  9 : printf("\07 Operation failed for insufficient space.\n");
		     return(-1);
           case 10 : printf("\07 The type had previously been accessed,");
                     printf("and not released.\n");
                     return(-1);
           case 11 : printf("\07 The command was out of range,");
                     printf(" or not implemented.\n");
                     return(-1);
           case 12 : printf("\07 The packet couldn't be sent.\n");
                     return(-1);
           case 13 : printf("\07 Hardware address couldn't be changed.\n");
                     return(-1);
           case 14 : printf("\07 Hardware address has bad length or format.\n");
                     return(-1);
           case 15 : printf("\007 Couldn't reset interface.\n");
                     return(-1);
           default : printf(" UNknown error\n");
                     return(-1);}}
   return(1);
}    
/*********************************************
 */
word get_vector(void)
  {
    char far *temp;
    word pkt_interrupt;

    for (pkt_interrupt=INT_FIRST; pkt_interrupt<=INT_LAST; ++pkt_interrupt)
        { temp = (char far *)(interrupts[pkt_interrupt]);
          if (!_fmemcmp(temp+3, PKT_LINE, sizeof(PKT_LINE)))
             break; }
    if (pkt_interrupt > INT_LAST )
       { printf("No packet Driver Found\n");
         return(0xFFFF); }
    return(pkt_interrupt);
}
/*********************************************
 */
DRVINFOptr driver_info(void)
{
    union  REGS  in, out;
    struct SREGS sreg;
    static DRVINFO info;
    char far *pktname;

    in.x.ax = PD_DRIVER_INFO;
    int86x(pkt_interrupt, &in, &out, &sreg);
    if (ERROR_check(out) < 0)
       return(NULL);
    pktname = (char far *) MK_FP(sreg.ds, out.x.si);
    _fstrcpy(info.Name, pktname);
    info.Version       = out.x.bx;
    info.Class         = out.h.ch;
    info.Type          = out.x.dx;
    info.Number        = out.h.cl;
    info.Functionality = out.h.al;
    return(&info);
}

/*********************************************
 */
int access_type(int if_class, int if_type, int if_number, char (far *type),
                int typelen, void (*receiver)())
{
    union  REGS  in, out;
    struct SREGS sreg;

    in.x.ax  = PD_ACCESS_TYPE | if_class;
    in.x.bx  = if_type;
    in.h.dl  = if_number;
    in.x.cx  = typelen;
    sreg.ds  = FP_SEG(type);
    in.x.si  = FP_OFF(type);
    sreg.es  = FP_SEG(receiver);
    in.x.di  = FP_OFF(receiver);
    int86x(pkt_interrupt, &in, &out, &sreg);
    if (ERROR_check(out) < 0)
       return(-1);
    return(out.x.ax);
}
/*********************************************
 */
void release_type(word handle)
{
    union  REGS  in, out;
    struct SREGS sreg;

    in.x.ax = PD_RELEASE_TYPE;
    in.x.bx = handle;
    int86x(pkt_interrupt, &in, &out, &sreg);
    ERROR_check(out);
}

/*********************************************
 */
int send_pkt(char far *buffer, int length)
{
    union  REGS  in, out;
    struct SREGS sreg;

    in.x.ax = PD_SEND_PKT;
    sreg.ds = FP_SEG(buffer);
    in.x.si = FP_OFF(buffer);
    in.x.cx = length;
    int86x(pkt_interrupt, &in, &out, &sreg);
    if (ERROR_check(out) < 0)
       return(-1); 
    return(1);
}
/*********************************************
 */
void terminate(void)
{
    union  REGS  in, out;
    struct SREGS sreg;

    in.x.ax = PD_TERMINATE;
    int86x(pkt_interrupt, &in, &out, &sreg);
    ERROR_check(out);
}
/*********************************************
 */
void get_address(word handle, char far *buff, int length)
{
    union  REGS  in, out;
    struct SREGS sreg;

    in.x.ax = PD_GET_ADDRESS;
    in.x.bx = handle;
    in.x.cx = length;
    sreg.es = FP_SEG(buff);
    in.x.di = FP_OFF(buff);
    int86x(pkt_interrupt, &in, &out, &sreg);
    ERROR_check(out);
}
/*********************************************
 */
void reset_interface(void)
{
    union  REGS  in, out;
    struct SREGS sreg;

    in.x.ax = PD_RESET_INTERFACE;
    int86x(pkt_interrupt, &in, &out, &sreg);
    ERROR_check(out);
}
/*********************************************
 */
void set_rcv_mode(word handle, word mode)
{
    union  REGS  in, out;
    struct SREGS sreg;

    in.x.ax = PD_SET_RCV_MODE;
    in.x.bx = handle;
    in.x.cx = mode;
    int86x(pkt_interrupt, &in, &out, &sreg);
    ERROR_check(out);
}
